//
//  SplashScreen.swift
//  WeatherApp
//
//  Created by lovepreet on 19/11/22.
//

import Foundation
import UIKit
import Lottie
class SplashScreen: UIViewController {
    @IBOutlet weak var splashAnimationView : LottieAnimationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureSplash()
        navigateToHome()
    }
    
    func configureSplash(){
        // 1. Set animation content mode
        splashAnimationView.contentMode = .scaleAspectFit
        // 2. Set animation loop mode
        splashAnimationView.loopMode = .loop
        // 3. Adjust animation speed
        splashAnimationView.animationSpeed = 0.5
        // 4. Play animation
        splashAnimationView.play()
    }
    
    func navigateToHome(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute:{
            if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WeatherViewController") as? WeatherViewController {
                if let navigator = self.navigationController {
                        navigator.pushViewController(viewController, animated: true)
                    }
                }
        })
    }
}
