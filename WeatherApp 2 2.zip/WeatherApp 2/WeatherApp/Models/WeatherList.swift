//
//  WeatherList.swift
//  WeatherApp
//
//  Created by lovepreet on 19/11/22.
//

import Foundation
struct WeatherList: Codable {
    let data: [WeatherListData]
    let count :Int
}
struct WeatherListData: Codable {
    let app_temp : Double
    let city_name : String
    let temp : Double
    let weather : WeatherDetails
}
struct WeatherDetails: Codable {
    let description : String
    let code : Int
    let icon : String
}
