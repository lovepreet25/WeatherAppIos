//
//  ViewController.swift
//  WeatherApp
//
//  Created by lovepreet on 19/11/22.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController {
    @IBOutlet weak var cityNameLabel : UILabel!
    @IBOutlet weak var temparatureNameLabel : UILabel!
    @IBOutlet weak var temparatureDescriptionLabel : UILabel!
    @IBOutlet weak var weatherIconImageView : UIImageView!
    
    //Declaration
    var locationManager = CLLocationManager()
    var weatherList = [WeatherListData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLocation()
    }
    
    
}
//MARK: - Local Functions
extension WeatherViewController{
    func configureLocation(){
        self.cityNameLabel.text = "Loading..."
        print("Accessing location")
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
    }
    func populateData(){
        print("Populating data")
        DispatchQueue.main.async {
            if self.weatherList.count > 0{
                self.cityNameLabel.text = self.weatherList[0].city_name
                self.temparatureNameLabel.text = "\(self.weatherList[0].temp) °C"
                self.temparatureDescriptionLabel.text = "\(self.weatherList[0].weather.description)"
                self.weatherIconImageView.image = UIImage(named: "\(self.weatherList[0].weather.icon).png")
            }
        }
    }
}

//MARK: - API Calls
extension WeatherViewController{
    func getWeatherDetails(latitude:Double,longitude:Double) {
        print("Calling API")
        let urlComponents = NSURLComponents(string: "https://weatherbit-v1-mashape.p.rapidapi.com/current")!
        
        urlComponents.queryItems = [
            URLQueryItem(name: "lon", value: ("\(longitude)")),
            URLQueryItem(name: "lat", value: ("\(latitude)"))
        ]
        let url = URL(string: urlComponents.string ?? "")
        guard let _url = url else { return }
        var request = URLRequest(url: _url)
        request.allHTTPHeaderFields = [
            "X-RapidAPI-Key": "2a9b722ac2msh5e40873067b6130p140393jsn93fd139a8ec7",
            "X-RapidAPI-Host": "weatherbit-v1-mashape.p.rapidapi.com"
        ]
        URLSession.shared.dataTask(with: request) { (data, response, err) in
            
            guard let _data = data else { return }
            do {
                if let string = String(data: _data, encoding: .utf8) {
                    print("Response:\(string)")
                }
                let getData = try JSONDecoder().decode(WeatherList.self, from: _data)
                self.weatherList = getData.data
                self.populateData()
            } catch let jsonErr {
                print("error serializing json: \(jsonErr)")
                
            }
            
        }.resume()
        
    }
}

//MARK: - Location Delegates
extension WeatherViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        DispatchQueue.main.async {
            self.getWeatherDetails(latitude: locValue.latitude, longitude: locValue.longitude)
        }
        
    }
}
